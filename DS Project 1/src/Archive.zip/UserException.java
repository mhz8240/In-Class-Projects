
public class UserException extends Exception{
	public UserException(String s) {
		super(s);
	}
}
